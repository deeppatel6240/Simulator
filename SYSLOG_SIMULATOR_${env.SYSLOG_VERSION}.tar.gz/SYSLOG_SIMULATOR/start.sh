#!/bin/sh

APP_NAME=SYSLOG_SIMULATOR

# run the simulator
java -jar $APP_NAME.jar
